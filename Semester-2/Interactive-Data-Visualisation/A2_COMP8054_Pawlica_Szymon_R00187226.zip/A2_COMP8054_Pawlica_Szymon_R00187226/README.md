To run the program follow these steps.

[Video link](https://drive.google.com/file/d/1ENoBGMKCCpGuhz7uFsGL0L0JgyBhb00i/view?usp=sharing)

1. Install node.js
2. Install npm
3. Install npm http-server
4. Run http-server
5. Visit localhost:8080