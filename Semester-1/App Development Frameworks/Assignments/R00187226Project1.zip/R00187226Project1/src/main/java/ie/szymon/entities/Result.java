package ie.szymon.entities;

public record Result(String directorFirstName, String directorLastName, Integer movieTakings, String movieName) {}
