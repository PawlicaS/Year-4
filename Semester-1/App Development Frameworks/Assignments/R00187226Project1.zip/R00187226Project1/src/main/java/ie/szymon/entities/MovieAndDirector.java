package ie.szymon.entities;

public record MovieAndDirector(String directorFirstName, String directorLastName, String movieTitle, Integer movieReleaseYear, Integer movieTakings) {}
